import json
import os
import re
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import repositories
from progress import percent_complete

ADDON_ID = repositories.ADDON_ID

def _error_text(exc):
    return repositories._error_text(exc)

def _has_addon(addon_id):
    return repositories._has_addon(addon_id)

def _wait_for_addon(addon_id, monitor, timeout):
    return repositories._wait_for_addon(addon_id, monitor, timeout)

ADDON = xbmcaddon.Addon()
# (addon_id, display_name) -- mirrors addon-catalog.md for summary labels only.
ADDON_DISPLAY_NAMES = {
    "plugin.video.elementum": "Elementum",
    "script.elementum.burst": "Elementum Burst",
    "context.elementum": "Elementum Context Menu",
    "plugin.video.jellycon": "JellyCon",
    "plugin.video.jellyfin": "Jellyfin for Kodi (classic)",
    "context.subtitlesdialog.contextmenu": "Subtitles Dialog - Contextmenu",
    "service.subtitles.all_subs_plus": "All Subs Plus",
    "service.subtitles.ktuvit_plus": "Ktuvit Plus",
    "service.subtitles.opensubtitles_plus": "OpenSubtitles Plus",
    "service.subtitles.wizdom_plus": "Wizdom Plus",
}

# ElementumOrg add-ons are served by a local "virtual repository" proxy on
# http://127.0.0.1:65223 that forwards to GitHub releases. That proxy is too
# slow for Kodi's package stat/download timeout, so these add-ons are fetched
# straight from GitHub instead. Value: (github_owner, github_repo, asset_kind).
ELEMENTUM_DIRECT_ADDONS = {
    "plugin.video.elementum": ("elgatito", "plugin.video.elementum", "client"),
    "script.elementum.burst": ("elgatito", "script.elementum.burst", "plain"),
    "context.elementum": ("elgatito", "context.elementum", "plain"),
}

# Directories scanned (in order) for a user-supplied local zip for an
# ElementumOrg add-on. A zip matches when its filename is ``<addon_id>.zip``
# or starts with ``<addon_id>-``. If found, it is used instead of downloading
# from GitHub, so the GitHub API is never needed.
LOCAL_ZIP_DIRS = (
    "special://home/addons/packages/",
    "special://profile/addon_data/{}/packages/".format(ADDON_ID),
)

ADDON_INSTALL_TIMEOUT = 60.0
MAX_ADDON_INSTALL_ATTEMPTS = 2


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def _update_progress(progress, percent, message):
    if progress is None:
        return
    try:
        progress.update(percent, message)
    except Exception as exc:
        log("Progress update failed ({})".format(_error_text(exc)), xbmc.LOGWARNING)


class _NullMonitor(object):
    def abortRequested(self):
        return False

    def waitForAbort(self, timeout):
        return False


def _resolve_monitor_and_selected(*args, **kwargs):
    monitor = None
    selected = None

    for arg in args:
        if hasattr(arg, "abortRequested") or hasattr(arg, "waitForAbort"):
            monitor = arg
        elif isinstance(arg, (list, tuple, set)):
            selected = list(arg)

    if monitor is None:
        monitor = kwargs.get("monitor") or kwargs.get("xbmc_monitor")
    if selected is None:
        for key in ("selected", "selected_ids", "addons", "addon_ids", "ids"):
            if key in kwargs and kwargs.get(key) is not None:
                value = kwargs.get(key)
                if isinstance(value, (list, tuple, set)):
                    selected = list(value)
                else:
                    selected = [value]
                break

    if monitor is None:
        monitor = _NullMonitor()
    if selected is None:
        selected = []

    # De-duplicate while preserving order.
    seen = set()
    deduped = []
    for addon_id in selected:
        if addon_id in seen:
            continue
        seen.add(addon_id)
        deduped.append(addon_id)
    return monitor, deduped


def _resolve_progress(*args, **kwargs):
    for key in ("progress", "progress_dialog", "background_progress"):
        value = kwargs.get(key)
        if value is not None:
            return value
    for arg in args:
        if (
            hasattr(arg, "update")
            and not hasattr(arg, "abortRequested")
            and not isinstance(arg, (list, tuple, set))
        ):
            return arg
    return None


def _is_valid_addon_id(addon_id):
    if not isinstance(addon_id, str) or not addon_id:
        return False
    for char in addon_id:
        if not (char.isalnum() or char in "._-"):
            return False
    return True


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Prevent urllib from following redirects so we can read ``Location``."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _elementum_latest_version(username, repository):
    """Resolve an add-on's latest release version without the GitHub API.

    The unauthenticated GitHub API (api.github.com) allows only 60 requests per
    hour per IP, so repeated runs hit ``HTTP Error 403: rate limit exceeded``.
    Instead we request ``https://github.com/{owner}/{repo}/releases/latest``,
    which answers with a 302 whose ``Location`` header points at the release
    tag. Parsing that header is not rate-limited.
    """
    url = "https://github.com/{}/{}/releases/latest".format(username, repository)
    request = urllib.request.Request(url, headers={"User-Agent": "MogliBootstrap/1.0"})
    opener = urllib.request.build_opener(_NoRedirectHandler())
    try:
        response = opener.open(request, timeout=30)
    except urllib.error.HTTPError as exc:
        location = exc.headers.get("Location", "")
    else:
        location = response.headers.get("Location", "")
        response.close()
    match = re.search(r"/tag/v?([0-9][^/?#]*)", location)
    if not match:
        return None
    return match.group(1)


def _elementum_download_url(addon_id, monitor):
    """Resolve a direct GitHub download URL for an ElementumOrg add-on.

    Returns None when the latest release cannot be determined.
    """
    username, repository, asset_kind = ELEMENTUM_DIRECT_ADDONS[addon_id]
    version = _elementum_latest_version(username, repository)
    if not version:
        return None
    if asset_kind == "client":
        asset_name = "{}-{}.client.zip".format(addon_id, version)
    else:
        asset_name = "{}-{}.zip".format(addon_id, version)
    return "https://github.com/{}/{}/releases/download/v{}/{}".format(
        username, repository, version, asset_name
    )


def _local_zip_for(addon_id):
    """Return a local zip path for an add-on if the user supplied one, else None."""
    for special_dir in LOCAL_ZIP_DIRS:
        try:
            directory = xbmcvfs.translatePath(special_dir)
        except Exception:
            continue
        if not directory:
            continue
        try:
            if not xbmcvfs.exists(directory):
                continue
            _dirs, files = xbmcvfs.listdir(directory)
        except Exception:
            continue
        for filename in files:
            if not filename.lower().endswith(".zip"):
                continue
            if filename == addon_id + ".zip" or filename.startswith(addon_id + "-"):
                return os.path.join(directory, filename)
    return None


def _install_addon_direct(addon_id, monitor):
    """Install an ElementumOrg add-on from a local zip or straight from GitHub.

    Returns "installed", "aborted", or a failure reason string.
    """
    # Prefer a user-supplied local zip so no network/API access is needed.
    destination = _local_zip_for(addon_id)
    if destination:
        log("Using local zip {} for {}".format(destination, addon_id))
    else:
        url = _elementum_download_url(addon_id, monitor)
        if not url:
            return "could not resolve GitHub download URL"

        temp_dir = xbmcvfs.translatePath("special://temp/")
        xbmcvfs.mkdirs(temp_dir)
        filename = os.path.basename(url.split("?")[0])
        destination = os.path.join(temp_dir, filename)

        log("Downloading {} from {}".format(addon_id, url))
        try:
            repositories._download_file(url, destination, None, monitor)
        except repositories._DownloadAborted:
            repositories._remove_file(destination)
            return "aborted"
        except Exception as exc:
            repositories._remove_file(destination)
            return "download failed ({})".format(repositories._error_text(exc))

    if monitor is not None and getattr(monitor, "abortRequested", lambda: False)():
        return "aborted"

    # Extract the archive into Kodi's addons directory and register it locally,
    # mirroring the repository installer (InstallFromZip is not headless).
    try:
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
    except Exception as exc:
        return "could not prepare addons path ({})".format(_error_text(exc))
    if not addons_dir:
        return "could not prepare addons path (translated path is empty)"

    log("Extracting {} to {}".format(destination, addons_dir))
    try:
        xbmc.executebuiltin(
            'Extract("{}", "{}")'.format(
                destination.replace('"', '\\"'), addons_dir.replace('"', '\\"')
            ),
            True,
        )
    except Exception as exc:
        return "extraction failed ({})".format(_error_text(exc))

    try:
        xbmc.executebuiltin("UpdateLocalAddons", True)
    except Exception as exc:
        return "local addon refresh failed ({})".format(_error_text(exc))

    # Install any missing (non-optional) dependencies from the normal repos.
    _install_missing_dependencies(addon_id, monitor)

    try:
        xbmc.executebuiltin("EnableAddon({})".format(addon_id), True)
        log("Enabled addon {}".format(addon_id))
    except Exception as exc:
        log("Could not enable addon {} ({})".format(addon_id, _error_text(exc)), xbmc.LOGWARNING)

    outcome = _wait_for_addon(addon_id, monitor, ADDON_INSTALL_TIMEOUT)
    if outcome == "present":
        log("Addon {} installed".format(addon_id))
        return "installed"
    if outcome == "aborted":
        return "aborted"
    return "not present within {} seconds after direct install".format(
        int(ADDON_INSTALL_TIMEOUT)
    )


def _install_missing_dependencies(addon_id, monitor):
    """Install the non-optional, non-builtin dependencies of an extracted add-on."""
    dependency_ids = _parse_addon_imports(addon_id)
    for dependency_id in dependency_ids:
        if monitor is not None and getattr(monitor, "abortRequested", lambda: False)():
            return
        if _has_addon(dependency_id):
            continue
        log("Installing dependency {} for {}".format(dependency_id, addon_id))
        try:
            xbmc.executebuiltin("InstallAddon({})".format(dependency_id), True)
        except Exception as exc:
            log(
                "Could not install dependency {} ({})".format(dependency_id, _error_text(exc)),
                xbmc.LOGWARNING,
            )
        _wait_for_addon(dependency_id, monitor, ADDON_INSTALL_TIMEOUT)


def _parse_addon_imports(addon_id):
    """Return the non-optional dependency add-on ids of an installed add-on."""
    addon_xml = repositories._addon_xml_path(addon_id)
    if not addon_xml:
        return []
    try:
        content = repositories._read_addon_xml(addon_xml)
        root = ET.fromstring(content)
    except Exception:
        return []
    imports = []
    for element in root.iter("import"):
        dependency_id = element.get("addon")
        optional = str(element.get("optional", "")).lower() == "true"
        if not dependency_id or optional:
            continue
        if dependency_id.startswith("xbmc.") or dependency_id.startswith("repository."):
            continue
        imports.append(dependency_id)
    return imports


def _install_one(addon_id, monitor):
    if not _is_valid_addon_id(addon_id):
        reason = "invalid addon id"
        log("Addon {} failed: {}".format(addon_id, reason), xbmc.LOGERROR)
        return reason

    log("Installing addon {}".format(addon_id))
    last_reason = None
    for attempt in range(1, MAX_ADDON_INSTALL_ATTEMPTS + 1):
        if monitor is not None and getattr(monitor, "abortRequested", lambda: False)():
            log("Addon {} aborted before attempt {}".format(addon_id, attempt))
            return "aborted"

        if _has_addon(addon_id):
            log("Addon {} installed".format(addon_id))
            return "installed"

        if attempt > 1:
            log(
                "Retrying addon {} (attempt {} of {}) after: {}".format(
                    addon_id, attempt, MAX_ADDON_INSTALL_ATTEMPTS, last_reason
                ),
                xbmc.LOGWARNING,
            )

        if addon_id in ELEMENTUM_DIRECT_ADDONS:
            outcome = _install_addon_direct(addon_id, monitor)
            if outcome == "installed":
                return "installed"
            if outcome == "aborted":
                log("Addon {} aborted".format(addon_id))
                return "aborted"
            last_reason = outcome
        else:
            try:
                xbmc.executebuiltin("InstallAddon({})".format(addon_id), True)
            except Exception as exc:
                last_reason = "install command failed ({})".format(_error_text(exc))
            else:
                outcome = _wait_for_addon(addon_id, monitor, ADDON_INSTALL_TIMEOUT)
                if outcome == "present":
                    log("Addon {} installed".format(addon_id))
                    return "installed"
                if outcome == "aborted":
                    log("Addon {} aborted".format(addon_id))
                    return "aborted"
                last_reason = "not present within {} seconds after InstallAddon".format(
                    int(ADDON_INSTALL_TIMEOUT)
                )

        log(
            "Addon {} attempt {} failed: {}".format(addon_id, attempt, last_reason),
            xbmc.LOGWARNING if attempt < MAX_ADDON_INSTALL_ATTEMPTS else xbmc.LOGERROR,
        )

    log("Addon {} failed: {}".format(addon_id, last_reason), xbmc.LOGERROR)
    return last_reason


def _enable_addon(addon_id):
    if not _is_valid_addon_id(addon_id):
        return
    try:
        xbmc.executebuiltin("EnableAddon({})".format(addon_id), True)
        log("Enabled addon {}".format(addon_id))
    except Exception as exc:
        log(
            "Could not enable addon {} ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGWARNING,
        )


def _show_summary(results):
    installed = results.get("installed", [])
    skipped = results.get("skipped", [])
    failed = results.get("failed", [])

    lines = [
        "Installed: {}".format(len(installed)),
        "Skipped (already installed): {}".format(len(skipped)),
        "Failed: {}".format(len(failed)),
    ]
    if failed:
        lines.append("")
        for entry in failed:
            if isinstance(entry, (tuple, list)):
                addon_id, reason = (list(entry) + [""])[:2]
            else:
                addon_id, reason = entry, ""
            name = ADDON_DISPLAY_NAMES.get(str(addon_id), addon_id)
            lines.append("- {}: {}".format(name, reason))

    message = "\n".join(lines)
    log("Addon installation summary:\n{}".format(message))

    try:
        dialog = xbmcgui.Dialog()
        dialog.ok("Mogli Addon Setup - Install Summary", message)
    except Exception as exc:
        log(
            "Could not show addon installation summary dialog ({})".format(_error_text(exc)),
            xbmc.LOGWARNING,
        )
        try:
            xbmcgui.Dialog().notification(
                "Mogli Addon Setup",
                "Installed {} / Skipped {} / Failed {}".format(
                    len(installed), len(skipped), len(failed)
                ),
                xbmcgui.NOTIFICATION_INFO,
                5000,
            )
        except Exception:
            pass


def install_addons(*args, **kwargs):
    """Install and enable the selected addons.

    Returns a dict with keys ``installed``, ``skipped``, ``failed``.
    ``failed`` entries are ``(addon_id, reason)`` tuples.
    """
    monitor, selected_ids = _resolve_monitor_and_selected(*args, **kwargs)
    progress = _resolve_progress(*args, **kwargs)

    results = {"installed": [], "skipped": [], "failed": []}
    total = len(selected_ids)
    completed = 0
    aborted = False

    for index, addon_id in enumerate(selected_ids):
        if monitor is not None and getattr(monitor, "abortRequested", lambda: False)():
            log("Abort requested; stopping addon installation")
            break

        name = ADDON_DISPLAY_NAMES.get(str(addon_id), addon_id)
        _update_progress(
            progress,
            percent_complete(index, total),
            "Installing {} ({}/{})".format(name, index + 1, total),
        )
        try:
            if _has_addon(addon_id):
                log("Addon {} already installed, skipping".format(addon_id))
                results["skipped"].append(addon_id)
                completed += 1
                _update_progress(
                    progress,
                    percent_complete(completed, total),
                    "{} already installed ({}/{})".format(name, completed, total),
                )
                continue

            outcome = _install_one(addon_id, monitor)
            if outcome == "installed":
                results["installed"].append(addon_id)
                _enable_addon(addon_id)
            elif outcome == "aborted":
                log("Abort requested; stopping addon installation")
                results["failed"].append((addon_id, "aborted"))
                completed += 1
                _update_progress(
                    progress,
                    percent_complete(completed, total),
                    "{} aborted ({}/{})".format(name, completed, total),
                )
                break
            else:
                results["failed"].append((addon_id, outcome))
        except Exception as exc:
            reason = "unexpected error ({})".format(_error_text(exc))
            log("Addon {} failed: {}".format(addon_id, reason), xbmc.LOGERROR)
            results["failed"].append((addon_id, reason))

        completed += 1
        _update_progress(
            progress,
            percent_complete(completed, total),
            "{} finished ({}/{})".format(name, completed, total),
        )

    if completed == total:
        _update_progress(progress, 100, "Addon installation finished")
    _show_summary(results)
    return results


# Common aliases for callers/tests that use different naming.
install_selected_addons = install_addons
install_selected = install_addons
install_addon_list = install_addons
run_addon_install = install_addons
