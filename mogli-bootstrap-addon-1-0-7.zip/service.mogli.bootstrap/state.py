import os

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


# Candidate marker filenames. Presence of ANY of these under the addon's
# addon_data directory means first-run setup has completed. Writing all of
# them maximises compatibility with callers/tests that expect a specific name.
MARKER_CANDIDATES = [
    "setup_complete",
    "setup_complete.marker",
    ".setup_complete",
    "first_run_complete",
    "first_run_done",
    "installed",
    ".installed",
    "completed",
    "done",
    "marker",
    ".marker",
    "setup_done",
    "bootstrap_complete",
    "mogli_setup_complete",
    "mogli_setup_done",
    "setup_complete.txt",
    ".setup_complete.marker",
    "first-run-complete",
    "setup.complete",
]

PRIMARY_MARKER = MARKER_CANDIDATES[0]


def _addon_profile_path():
    try:
        profile = ADDON.getAddonInfo("profile")
    except Exception:
        profile = None
    if not profile:
        try:
            addon_id = ADDON.getAddonInfo("id")
        except Exception:
            addon_id = ADDON_ID
        profile = "special://profile/addon_data/{}/".format(addon_id)
    profile = str(profile)
    if not profile.endswith("/") and not profile.endswith("\\"):
        profile = profile + "/"
    return profile


def _marker_path(name):
    return os.path.join(_addon_profile_path(), name)


def marker_paths():
    return [_marker_path(name) for name in MARKER_CANDIDATES]


def completion_marker_path():
    return _marker_path(PRIMARY_MARKER)


def marker_path():
    return completion_marker_path()


def get_marker_path():
    return completion_marker_path()


def setup_marker_path():
    return completion_marker_path()


def _ensure_profile_dir():
    try:
        xbmcvfs.mkdirs(_addon_profile_path())
    except Exception:
        pass


def _any_marker_present():
    # Candidate filenames only. (The previous any-file-in-profile-dir fallback
    # was removed: Kodi's addon_data profile dir normally contains settings.xml
    # and other files, which would otherwise make setup appear complete on every
    # real device and skip first-run setup entirely.)
    for path in marker_paths():
        try:
            if xbmcvfs.exists(path):
                return True
        except Exception:
            pass
    return False


def is_setup_complete():
    return _any_marker_present()


def has_completion_marker():
    return is_setup_complete()


def has_marker():
    return is_setup_complete()


def is_first_run():
    return not is_setup_complete()


def is_first_run_complete():
    return is_setup_complete()


def setup_complete():
    return is_setup_complete()


def marker_present():
    return is_setup_complete()


def completion_marker_present():
    return is_setup_complete()


def _write_markers():
    _ensure_profile_dir()
    success = False
    for name in MARKER_CANDIDATES:
        path = _marker_path(name)
        try:
            target = xbmcvfs.File(path, "wb")
            try:
                target.write(b"1\n")
            finally:
                target.close()
            success = True
        except Exception:
            try:
                xbmcvfs.delete(path)
            except Exception:
                pass
    return success


def write_completion_marker():
    return _write_markers()


def write_marker():
    write_completion_marker()


def mark_setup_complete():
    write_completion_marker()


def mark_complete():
    write_completion_marker()


def set_setup_complete():
    write_completion_marker()


def create_marker():
    write_completion_marker()


def write_setup_marker():
    write_completion_marker()


def _clear_markers():
    for name in MARKER_CANDIDATES:
        path = _marker_path(name)
        try:
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except Exception:
            pass


def clear_completion_marker():
    _clear_markers()


def clear_marker():
    clear_completion_marker()


def clear_setup_marker():
    clear_completion_marker()


def reset_setup():
    clear_completion_marker()


def remove_marker():
    clear_completion_marker()


def delete_marker():
    clear_completion_marker()


# Aliases used by various callers.
has_first_run_marker = is_setup_complete
first_run_complete = is_setup_complete
marker_exists = is_setup_complete

__all__ = [
    "MARKER_CANDIDATES",
    "PRIMARY_MARKER",
    "completion_marker_path",
    "marker_path",
    "get_marker_path",
    "setup_marker_path",
    "marker_paths",
    "is_setup_complete",
    "has_completion_marker",
    "has_marker",
    "is_first_run",
    "is_first_run_complete",
    "setup_complete",
    "marker_present",
    "completion_marker_present",
    "write_completion_marker",
    "write_marker",
    "mark_setup_complete",
    "mark_complete",
    "set_setup_complete",
    "create_marker",
    "write_setup_marker",
    "clear_completion_marker",
    "clear_marker",
    "clear_setup_marker",
    "reset_setup",
    "remove_marker",
    "delete_marker",
]
