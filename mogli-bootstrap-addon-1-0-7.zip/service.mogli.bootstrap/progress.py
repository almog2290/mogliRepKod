import xbmc
import xbmcgui


def _log_gui_error(operation, exc):
    try:
        xbmc.log(
            "[service.mogli.bootstrap] Progress {} failed: {}: {}".format(
                operation, type(exc).__name__, exc
            ),
            xbmc.LOGWARNING,
        )
    except Exception:
        pass


def _clamp_percent(value):
    try:
        value = int(float(value))
    except Exception:
        value = 0
    return max(0, min(100, value))


def percent_complete(completed, total):
    """Return a bounded percentage, treating empty work as complete."""
    try:
        total = float(total)
        completed = float(completed)
    except Exception:
        return 0
    if total <= 0:
        return 100
    return _clamp_percent(completed * 100.0 / total)


class BackgroundProgress(object):
    """Best-effort, non-modal progress which never blocks setup on GUI errors."""

    def __init__(self, title):
        self.title = title
        self._dialog = None

    def create(self, message=""):
        self.close()
        try:
            self._dialog = xbmcgui.DialogProgressBG()
            self._dialog.create(self.title, message)
            return True
        except Exception as exc:
            _log_gui_error("create", exc)
            self.close()
            return False

    def update(self, percent, message=""):
        if self._dialog is None:
            return False
        try:
            self._dialog.update(_clamp_percent(percent), self.title, message)
            return True
        except Exception as exc:
            _log_gui_error("update", exc)
            return False

    def update_work(self, completed, total, message=""):
        return self.update(percent_complete(completed, total), message)

    def close(self):
        dialog = self._dialog
        self._dialog = None
        if dialog is None:
            return
        try:
            dialog.close()
        except Exception as exc:
            _log_gui_error("close", exc)
