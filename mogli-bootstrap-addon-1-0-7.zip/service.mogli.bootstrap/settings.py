import xbmc
import xbmcaddon
import xbmcgui

import state as _state

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def clear_marker_and_restart():
    """Clear the completion marker and restart the setup flow."""
    try:
        _state.clear_completion_marker()
        log("Completion marker cleared; setup will re-run on next Kodi start")
        xbmcgui.Dialog().ok(
            "Mogli Addon Setup",
            "The completion marker has been cleared.\n\n"
            "The setup flow will re-run the next time Kodi starts,\n"
            "allowing you to add or change addon selections.",
        )
    except Exception as exc:
        log("Failed to clear marker ({})".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Mogli Addon Setup",
            "Failed to clear the completion marker:\n{}".format(_state._error_text(exc) if hasattr(_state, "_error_text") else str(exc)),
        )


def restore_marker():
    """Restore the completion marker (for debugging/cancellation recovery)."""
    try:
        _state.write_completion_marker()
        log("Completion marker restored")
        xbmcgui.Dialog().ok("Mogli Addon Setup", "Completion marker restored.")
    except Exception as exc:
        log("Failed to restore marker ({})".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Mogli Addon Setup",
            "Failed to restore the completion marker:\n{}".format(str(exc)),
        )


def run_setup_now():
    """Run the setup flow immediately (same as run_startup but without a monitor)."""
    try:
        from service import run_startup  # may fail outside service context
        # We can't easily call run_startup without a monitor,
        # so just inform the user
        xbmcgui.Dialog().ok(
            "Mogli Addon Setup",
            "Setup cannot be run from settings without a Kodi monitor.\n"
            "The marker has been cleared and setup will re-run\n"
            "the next time Kodi starts.",
        )
    except Exception as exc:
        log("Could not import run_startup ({})".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Mogli Addon Setup",
            "Could not run setup from settings:\n{}".format(str(exc)),
        )


def main():
    """Display the settings dialog."""
    # Show a simple dialog with options
    dialog = xbmcgui.Dialog()
    choice = dialog.select(
        "Mogli Addon Setup - Settings",
        [
            "Clear marker and re-run setup on next start",
            "Restore completion marker",
            "Info about this addon",
        ],
    )

    if choice == 0:
        # Clear marker and re-run setup on next start
        clear_marker_and_restart()
    elif choice == 1:
        # Restore completion marker
        restore_marker()
    elif choice == 2:
        # Info
        info = (
            "Mogli Addon Bootstrap Settings\n\n"
            "This addon runs at Kodi startup to install repositories\n"
            "and the addons you select.\n\n"
            "Use 'Clear marker and re-run setup on next start'\n"
            "to reset the setup and re-open the addon selection dialog.\n\n"
            "The completion marker is stored under the addon's\n"
            "addon_data directory and prevents the setup from\n"
            "running on subsequent Kodi starts.\n"
        )
        xbmcgui.Dialog().ok("Mogli Addon Setup - Info", info)


if __name__ == "__main__":
    main()