import xbmc
import xbmcaddon

from repositories import install_repositories
from selection import show_selection_dialog
from addons import install_addons
from progress import BackgroundProgress
import state as _state

# Re-export marker helpers so callers can reach them via `service.`.
# Only public helpers are re-exported (no private helpers or imported modules).
_STATE_EXPORTS = [
    "MARKER_CANDIDATES",
    "PRIMARY_MARKER",
    "completion_marker_path",
    "marker_path",
    "get_marker_path",
    "setup_marker_path",
    "marker_paths",
    "is_setup_complete",
    "has_completion_marker",
    "has_marker",
    "is_first_run",
    "is_first_run_complete",
    "setup_complete",
    "marker_present",
    "completion_marker_present",
    "write_completion_marker",
    "write_marker",
    "mark_setup_complete",
    "mark_complete",
    "set_setup_complete",
    "create_marker",
    "write_setup_marker",
    "clear_completion_marker",
    "clear_marker",
    "clear_setup_marker",
    "reset_setup",
    "remove_marker",
    "delete_marker",
]
for _name in _STATE_EXPORTS:
    if hasattr(_state, _name):
        globals()[_name] = getattr(_state, _name)

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def run_startup(monitor):
    log("Bootstrap service started, version {}".format(ADDON.getAddonInfo("version")))

    # First-run guard: a completion marker means setup already finished.
    try:
        if _state.is_setup_complete():
            log("Setup already completed; skipping setup")
            return
    except Exception as exc:
        log("Could not check completion marker ({}); continuing".format(exc), xbmc.LOGWARNING)

    log("Repository setup starting")
    repo_progress = BackgroundProgress("Mogli Addon Setup - Repositories")
    try:
        repo_progress.create("Preparing repository setup...")
        repo_result = install_repositories(monitor, progress=repo_progress)
    finally:
        repo_progress.close()
    if not isinstance(repo_result, dict):
        repo_result = {"failed_repos": ["repository setup unknown"], "proxy": "aborted"}
    repo_failures = repo_result.get("failed_repos", []) or []
    proxy_status = repo_result.get("proxy", "aborted")
    log("Repository setup finished")
    if monitor.abortRequested():
        log("Abort requested; skipping addon selection dialog")
        return
    if proxy_status not in ("ready", None):
        log("Elementum proxy not ready ({}); setup will retry next start".format(proxy_status), xbmc.LOGERROR)

    selected = show_selection_dialog(monitor)
    if selected is None:
        log("Addon selection cancelled; setup aborts, no completion marker written")
        return
    log("Selected addons: {}".format(", ".join(selected)))
    log("Addon installation starting")
    addon_progress = BackgroundProgress("Mogli Addon Setup - Addons")
    try:
        addon_progress.create("Preparing addon installation...")
        results = install_addons(monitor, selected, progress=addon_progress)
    finally:
        addon_progress.close()
    if not isinstance(results, dict):
        results = {"installed": [], "skipped": [], "failed": ["addon installation unknown"]}
    log(
        "Addon installation finished: installed={}, skipped={}, failed={}".format(
            len(results.get("installed", [])),
            len(results.get("skipped", [])),
            len(results.get("failed", [])),
        )
    )

    if monitor.abortRequested():
        log("Abort requested; no completion marker written")
        return

    failed_addons = results.get("failed", []) or []
    if repo_failures or proxy_status not in ("ready", None) or failed_addons:
        log(
            "Setup incomplete (repos_failed={}, proxy={}, addons_failed={}); no completion marker written".format(
                len(repo_failures), proxy_status, len(failed_addons)
            ),
            xbmc.LOGERROR if (repo_failures or failed_addons) else xbmc.LOGINFO,
        )
        return

    try:
        marker_written = _state.write_completion_marker()
        if marker_written:
            log("Setup completed successfully; completion marker written")
        else:
            log("Setup completed but completion marker could not be written; will retry next start", xbmc.LOGERROR)
    except Exception as exc:
        log("Could not write completion marker ({})".format(exc), xbmc.LOGERROR)


def main():
    monitor = xbmc.Monitor()
    try:
        run_startup(monitor)
    except Exception as exc:
        log("Startup failed: {}".format(exc), xbmc.LOGERROR)
        return
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
    log("Bootstrap service stopping")


if __name__ == "__main__":
    main()
