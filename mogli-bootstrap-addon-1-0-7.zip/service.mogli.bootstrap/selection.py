import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

# (addon_id, display_name, default_ticked) -- matches addon-catalog.md
ADDONS = (
    ("plugin.video.elementum", "Elementum", True),
    ("script.elementum.burst", "Elementum Burst", True),
    ("context.elementum", "Elementum Context Menu", True),
    ("plugin.video.jellycon", "JellyCon", True),
    ("plugin.video.jellyfin", "Jellyfin for Kodi (classic)", False),
    ("context.subtitlesdialog.contextmenu", "Subtitles Dialog - Contextmenu", True),
    ("service.subtitles.all_subs_plus", "All Subs Plus", True),
    ("service.subtitles.ktuvit_plus", "Ktuvit Plus", True),
    ("service.subtitles.opensubtitles_plus", "OpenSubtitles Plus", True),
    ("service.subtitles.wizdom_plus", "Wizdom Plus", True),
)

JELLYFIN_CLIENTS = {"plugin.video.jellycon", "plugin.video.jellyfin"}
DIALOG_TITLE = "Mogli Addon Setup - Choose Addons to Install"


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def _resolve_mutual_exclusivity(selected_ids):
    """At most one Jellyfin client. JellyCon wins as the pre-ticked default."""
    jellyfin_selected = [aid for aid in selected_ids if aid in JELLYFIN_CLIENTS]
    if len(jellyfin_selected) > 1:
        log("Both Jellyfin clients selected; keeping JellyCon as default")
        selected_ids = [aid for aid in selected_ids if aid != "plugin.video.jellyfin"]
    return selected_ids


def show_selection_dialog(monitor):
    """Show the addon selection dialog.

    Returns the ticked addon id list on confirm, or None on cancel/abort.
    """
    if monitor.abortRequested():
        return None

    titles = [name for _, name, _ in ADDONS]
    default_indices = [i for i, (_, _, ticked) in enumerate(ADDONS) if ticked]

    dialog = xbmcgui.Dialog()
    result = dialog.multiselect(DIALOG_TITLE, titles, preselect=default_indices)

    if monitor.abortRequested():
        log("Abort requested while selection dialog was open; aborting")
        return None

    if result is None:
        log("User cancelled the addon selection dialog")
        return None

    selected_ids = [ADDONS[i][0] for i in result]
    selected_ids = _resolve_mutual_exclusivity(selected_ids)
    log("Addon selection confirmed: {}".format(", ".join(selected_ids)))
    return selected_ids
