import os
import re
import socket
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import namedtuple

import xbmc
import xbmcaddon
import xbmcvfs

from progress import percent_complete

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

Repository = namedtuple("Repository", "addon_id zip_url patch_jellyfin")

ELEMENTUM_PROXY_HOST = "127.0.0.1"
ELEMENTUM_PROXY_PORT = 65223
JELLYFIN_SOURCE_ROOT = "https://repo.jellyfin.org/releases/client/kodi"
JELLYFIN_PY3_SOURCE = JELLYFIN_SOURCE_ROOT + "/py3"
BUREKAS_REPOSITORY_ID = "repository.burekasKodi"
ELEMENTUM_REPOSITORY_ID = "repository.elementumorg"

REPOSITORIES = (
    Repository(
        "repository.elementumorg",
        "https://raw.githubusercontent.com/almog2290/mogliRepKod/main/repository.elementumorg-0.0.2.zip",
        False,
    ),
    Repository(
        "repository.jellyfin.kodi",
        "https://almog2290.github.io/mogliRepKod/repository.jellyfin.kodi.zip",
        True,
    ),
    Repository(
        "repository.burekasKodi",
        "https://raw.githubusercontent.com/almog2290/mogliRepKod/main/repository.burekasKodi-1.0.2.zip",
        False,
    ),
)

REPO_INSTALL_TIMEOUT = 60.0
PROXY_TIMEOUT = 60.0
POLL_INTERVAL = 1.0
DOWNLOAD_TIMEOUT = 60.0
ADDON_PATH_ROOTS = (
    "special://home/addons/",
    "special://xbmc/addons/",
    "special://xbmcbin/addons/",
)

_JELLYFIN_SOURCE_PATTERN = re.compile(
    re.escape(JELLYFIN_SOURCE_ROOT) + r"(?![/]?py3)(?P<suffix>/[^\s\"'<>]*)?"
)

_ELEMENTUM_HANDLER_PATCHES = (
    (
        "    def do_GET(self):\n        self._handle_request(self.get_routes)\n",
        "    def do_GET(self):\n        self._handle_request(self.get_routes)\n\n"
        "    def do_HEAD(self):\n        self._handle_request(self.get_routes)\n",
    ),
    (
        "    def send_response_with_data(self, data, content_type, code=200):\n"
        "        self.send_response(code)\n"
        "        self.send_header(\"Content-Type\", content_type)\n"
        "        self.send_header(\"Content-Length\", str(len(data)))\n"
        "        self.end_headers()\n"
        "        self.wfile.write(data)\n",
        "    def send_response_with_data(self, data, content_type, code=200):\n"
        "        self.send_response(code)\n"
        "        self.send_header(\"Content-Type\", content_type)\n"
        "        self.send_header(\"Content-Length\", str(len(data)))\n"
        "        self.end_headers()\n"
        "        if self.command != \"HEAD\":\n"
        "            self.wfile.write(data)\n",
    ),
    (
        "    def send_file_contents(self, fp, code, length=None, content_type=None,\n"
        "                           content_disposition=None, chunked=True):\n"
        "        self.send_response(code)\n\n"
        "        if content_type:\n"
        "            self.send_header(\"Content-Type\", content_type)\n"
        "        if content_disposition:\n"
        "            self.send_header(\"Content-Disposition\", content_disposition)\n"
        "        if length:\n"
        "            self.send_header(\"Content-Length\", length)\n"
        "            chunked = False\n"
        "        else:\n"
        "            if chunked:\n"
        "                self.send_header(\"Transfer-Encoding\", \"chunked\")\n"
        "            self.send_header(\"Connection\", \"close\")\n\n"
        "        self.end_headers()\n\n"
        "        if chunked:\n"
        "            self._send_chunked(fp)\n"
        "        else:\n"
        "            copyfileobj(fp, self.wfile)\n",
        "    def send_file_contents(self, fp, code, length=None, content_type=None,\n"
        "                           content_disposition=None, chunked=True):\n"
        "        self.send_response(code)\n\n"
        "        if content_type:\n"
        "            self.send_header(\"Content-Type\", content_type)\n"
        "        if content_disposition:\n"
        "            self.send_header(\"Content-Disposition\", content_disposition)\n"
        "        if length:\n"
        "            self.send_header(\"Content-Length\", length)\n"
        "            chunked = False\n"
        "        else:\n"
        "            if chunked:\n"
        "                self.send_header(\"Transfer-Encoding\", \"chunked\")\n"
        "            self.send_header(\"Connection\", \"close\")\n\n"
        "        self.end_headers()\n\n"
        "        if self.command == \"HEAD\":\n"
        "            return\n\n"
        "        if chunked:\n"
        "            self._send_chunked(fp)\n"
        "        else:\n"
        "            copyfileobj(fp, self.wfile)\n",
    ),
)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def _error_text(exc):
    text = str(exc)
    if text:
        return "{}: {}".format(type(exc).__name__, text)
    return type(exc).__name__


def _update_progress(progress, percent, message):
    if progress is None:
        return
    try:
        progress.update(percent, message)
    except Exception as exc:
        log("Progress update failed ({})".format(_error_text(exc)), xbmc.LOGWARNING)


class _ProgressView(object):
    """Map a subtask's percentage into a range of its parent progress."""

    def __init__(self, parent, start, span, prefix=""):
        self.parent = parent
        self.start = start
        self.span = span
        self.prefix = prefix

    def update(self, percent, message=""):
        if self.parent is None:
            return
        try:
            fraction = max(0.0, min(100.0, float(percent))) / 100.0
        except Exception:
            fraction = 0.0
        if self.prefix and message:
            message = "{}: {}".format(self.prefix, message)
        elif self.prefix:
            message = self.prefix
        _update_progress(self.parent, self.start + self.span * fraction, message)


class _DownloadAborted(Exception):
    pass


def _addon_xml_path(addon_id):
    for special_root in ADDON_PATH_ROOTS:
        try:
            addon_root = xbmcvfs.translatePath(special_root)
            addon_xml = os.path.join(addon_root, addon_id, "addon.xml")
            if addon_root and xbmcvfs.exists(addon_xml):
                return addon_xml
        except Exception:
            continue
    return None


def _has_addon(addon_id):
    return bool(
        xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))
        and _addon_xml_path(addon_id)
    )


def _remove_file(path):
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception:
        pass


def _download_file(url, destination, progress=None, monitor=None):
    request = urllib.request.Request(url, headers={"User-Agent": "MogliBootstrap/1.0"})
    response = urllib.request.urlopen(request, timeout=DOWNLOAD_TIMEOUT)
    try:
        try:
            total = int(response.headers.get("Content-Length", 0))
        except Exception:
            total = 0
        downloaded = 0
        target = xbmcvfs.File(destination, "wb")
        try:
            while True:
                if monitor is not None and monitor.abortRequested():
                    raise _DownloadAborted()
                chunk = response.read(65536)
                if not chunk:
                    break
                target.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    _update_progress(
                        progress,
                        downloaded * 100.0 / total,
                        "Downloading archive",
                    )
        finally:
            target.close()
    finally:
        response.close()


def _repository_zip_path(repo):
    temp_dir = xbmcvfs.translatePath("special://temp/")
    xbmcvfs.mkdirs(temp_dir)
    filename = os.path.basename(urllib.parse.urlparse(repo.zip_url).path)
    if not filename:
        filename = repo.addon_id + ".zip"
    return os.path.join(temp_dir, filename)


def _wait_for_addon(addon_id, monitor, timeout):
    deadline = time.monotonic() + timeout
    while True:
        if _has_addon(addon_id):
            return "present"
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return "timeout"
        if monitor.waitForAbort(min(POLL_INTERVAL, remaining)):
            return "aborted"


def _enable_repository(addon_id):
    try:
        xbmc.executebuiltin("EnableAddon({})".format(addon_id), True)
    except Exception as exc:
        return "could not enable repository ({})".format(_error_text(exc))
    log("Enabled repository {}".format(addon_id))
    return None


def _install_repository(repo, monitor, progress=None):
    try:
        destination = _repository_zip_path(repo)
    except Exception as exc:
        return "could not prepare temp path ({})".format(_error_text(exc))

    log("Downloading {} from {}".format(repo.addon_id, repo.zip_url))
    _update_progress(progress, 0, "Downloading archive")
    download_progress = _ProgressView(progress, 0, 75)
    try:
        _download_file(repo.zip_url, destination, download_progress, monitor)
    except _DownloadAborted:
        _remove_file(destination)
        return "aborted"
    except Exception as exc:
        _remove_file(destination)
        return "download failed ({})".format(_error_text(exc))

    if monitor.abortRequested():
        return "aborted"

    try:
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
    except Exception as exc:
        return "could not prepare addons path ({})".format(_error_text(exc))
    if not addons_dir:
        return "could not prepare addons path (translated path is empty)"

    log("Extracting {} to {}".format(destination, addons_dir))
    _update_progress(progress, 80, "Extracting archive")
    try:
        xbmc.executebuiltin(
            'Extract("{}", "{}")'.format(
                destination.replace('"', '\\"'), addons_dir.replace('"', '\\"')
            ),
            True,
        )
    except Exception as exc:
        return "extraction failed ({})".format(_error_text(exc))

    _update_progress(progress, 88, "Applying repository compatibility fixes")
    if not _normalize_repository(repo):
        return "repository metadata normalization failed"
    _update_progress(progress, 90, "Refreshing local addons")
    if not _refresh_local_addons():
        return "local addon refresh failed"

    if monitor.abortRequested():
        return "aborted"

    _update_progress(progress, 93, "Enabling repository")
    enable_error = _enable_repository(repo.addon_id)
    if enable_error:
        return enable_error

    _update_progress(progress, 95, "Confirming repository installation")
    outcome = _wait_for_addon(repo.addon_id, monitor, REPO_INSTALL_TIMEOUT)
    if outcome == "present":
        log("Repository {} installed".format(repo.addon_id))
        _update_progress(progress, 100, "Repository installed")
        return "installed"
    if outcome == "aborted":
        return "aborted"
    return "not present within {} seconds after extraction".format(int(REPO_INSTALL_TIMEOUT))


def _read_addon_xml(addon_xml):
    source = xbmcvfs.File(addon_xml)
    try:
        content = source.read()
    finally:
        source.close()
    if isinstance(content, bytes):
        content = content.decode("utf-8")
    return content


def _write_addon_xml(addon_xml, content):
    target = xbmcvfs.File(addon_xml, "w")
    try:
        target.write(content)
    finally:
        target.close()


def _patch_elementum_repository(addon_id):
    addon_xml = _addon_xml_path(addon_id)
    if not addon_xml:
        log(
            "Could not patch {}: addon.xml missing from Kodi addon paths".format(addon_id),
            xbmc.LOGERROR,
        )
        return False

    handler_path = os.path.join(os.path.dirname(addon_xml), "lib", "httpserver.py")
    if not xbmcvfs.exists(handler_path):
        log(
            "Could not patch {}: HTTP handler source is missing at {}".format(
                addon_id, handler_path
            ),
            xbmc.LOGERROR,
        )
        return False

    try:
        source_file = xbmcvfs.File(handler_path)
        try:
            source = source_file.read()
        finally:
            source_file.close()
        if isinstance(source, bytes):
            source = source.decode("utf-8")
    except Exception as exc:
        log(
            "Could not read {} HTTP handler ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return False

    patched = source
    for original, replacement in _ELEMENTUM_HANDLER_PATCHES:
        if replacement in patched:
            continue
        if patched.count(original) != 1:
            log(
                "Could not patch {}: expected HTTP handler block was not found".format(
                    addon_id
                ),
                xbmc.LOGERROR,
            )
            return False
        patched = patched.replace(original, replacement, 1)

    if patched == source:
        log("Repository {} already supports package HEAD requests".format(addon_id))
        return True

    try:
        target = xbmcvfs.File(handler_path, "w")
        try:
            target.write(patched)
        finally:
            target.close()
    except Exception as exc:
        log(
            "Could not write {} HTTP handler ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return False

    log("Patched {} HTTP handler for package HEAD requests".format(addon_id))
    return True


def _patch_jellyfin_repository(addon_id):
    addon_xml = _addon_xml_path(addon_id)
    if not addon_xml:
        log(
            "Could not patch {}: addon.xml missing from Kodi addon paths".format(addon_id),
            xbmc.LOGERROR,
        )
        return False

    try:
        content = _read_addon_xml(addon_xml)
    except Exception as exc:
        log(
            "Could not read {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return False

    patched, count = _JELLYFIN_SOURCE_PATTERN.subn(
        lambda match: JELLYFIN_PY3_SOURCE + (match.group("suffix") or ""),
        content,
    )
    if count == 0:
        log("Repository {} already points at {}".format(addon_id, JELLYFIN_PY3_SOURCE))
        return True

    try:
        _write_addon_xml(addon_xml, patched)
    except Exception as exc:
        log(
            "Could not write {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return False

    log(
        "Patched {} source URLs to {} ({} replacement{})".format(
            addon_id,
            JELLYFIN_PY3_SOURCE,
            count,
            "" if count == 1 else "s",
        )
    )
    return True


def _normalize_burekas_repository(addon_id):
    addon_xml = _addon_xml_path(addon_id)
    if not addon_xml:
        log(
            "Could not normalize {}: addon.xml missing from Kodi addon paths".format(addon_id),
            xbmc.LOGERROR,
        )
        return False

    try:
        content = _read_addon_xml(addon_xml)
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
        root = ET.fromstring(content, parser=parser)
    except Exception as exc:
        log(
            "Could not parse {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return False

    extensions = [
        extension
        for extension in root.iter("extension")
        if extension.get("point") == "xbmc.addon.repository"
    ]
    if not extensions or any(
        not any(child.tag == "dir" for child in extension) for extension in extensions
    ):
        log(
            "Could not normalize {}: repository <dir> source is missing".format(addon_id),
            xbmc.LOGERROR,
        )
        return False

    changed = False
    for extension in extensions:
        for child in list(extension):
            if child.tag in ("info", "checksum", "datadir"):
                extension.remove(child)
                changed = True

    if not changed:
        log("Repository {} metadata is already normalized".format(addon_id))
        return True

    try:
        declaration = content.lstrip().startswith("<?xml")
        patched = ET.tostring(root, encoding="unicode", xml_declaration=declaration)
        _write_addon_xml(addon_xml, patched)
    except Exception as exc:
        log(
            "Could not write {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return False

    log("Removed legacy repository fields from {}".format(addon_id))
    return True


def _normalize_repository(repo):
    if repo.addon_id == ELEMENTUM_REPOSITORY_ID:
        return _patch_elementum_repository(repo.addon_id)
    if repo.patch_jellyfin:
        return _patch_jellyfin_repository(repo.addon_id)
    if repo.addon_id == BUREKAS_REPOSITORY_ID:
        return _normalize_burekas_repository(repo.addon_id)
    return True


def _refresh_local_addons():
    try:
        xbmc.executebuiltin("UpdateLocalAddons", True)
    except Exception as exc:
        log("Could not refresh local addons ({})".format(_error_text(exc)), xbmc.LOGERROR)
        return False
    return True


def _update_addon_repos():
    log("Updating addon repositories")
    try:
        xbmc.executebuiltin("UpdateAddonRepos", True)
    except Exception as exc:
        log(
            "Could not update addon repositories ({})".format(_error_text(exc)),
            xbmc.LOGERROR,
        )
        return False
    return True


def _proxy_responds():
    try:
        connection = socket.create_connection(
            (ELEMENTUM_PROXY_HOST, ELEMENTUM_PROXY_PORT),
            timeout=1.0,
        )
    except OSError:
        return False
    connection.close()
    return True


def wait_for_elementum_proxy(monitor, progress=None):
    deadline = time.monotonic() + PROXY_TIMEOUT
    while True:
        if monitor.abortRequested():
            log("Abort requested while waiting for the Elementum proxy")
            return "aborted"
        _update_progress(progress, 100, "Waiting for the Elementum proxy")
        if _proxy_responds():
            log(
                "Elementum proxy is responding at {}:{}".format(
                    ELEMENTUM_PROXY_HOST,
                    ELEMENTUM_PROXY_PORT,
                )
            )
            _update_progress(progress, 100, "Elementum proxy is ready")
            return "ready"
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            log(
                "Elementum proxy did not respond at {}:{} within {} seconds".format(
                    ELEMENTUM_PROXY_HOST,
                    ELEMENTUM_PROXY_PORT,
                    int(PROXY_TIMEOUT),
                ),
                xbmc.LOGERROR,
            )
            _update_progress(progress, 100, "Elementum proxy is not responding")
            return "timeout"
        if monitor.waitForAbort(min(POLL_INTERVAL, remaining)):
            log("Abort requested while waiting for the Elementum proxy")
            return "aborted"


def install_repositories(monitor, progress=None):
    failed_repos = []
    total = len(REPOSITORIES)
    for index, repo in enumerate(REPOSITORIES):
        if monitor.abortRequested():
            log("Abort requested; stopping repository installation")
            return {"failed_repos": failed_repos, "proxy": "aborted"}
        _update_progress(
            progress,
            percent_complete(index, total),
            "Checking {}".format(repo.addon_id),
        )
        addon_xml = _addon_xml_path(repo.addon_id)
        if addon_xml:
            if not _normalize_repository(repo):
                outcome = "repository metadata normalization failed"
            elif not _refresh_local_addons():
                outcome = "local addon refresh failed"
            elif monitor.abortRequested():
                log("Abort requested after refreshing {}".format(repo.addon_id))
                return {"failed_repos": failed_repos, "proxy": "aborted"}
            elif _has_addon(repo.addon_id):
                log("Repository {} already installed, skipping".format(repo.addon_id))
                _update_progress(
                    progress,
                    percent_complete(index + 1, total),
                    "{} already installed; skipping".format(repo.addon_id),
                )
                continue
            else:
                log("Repository {} is present but disabled; enabling".format(repo.addon_id))
                outcome = _enable_repository(repo.addon_id)
                if not outcome:
                    outcome = _wait_for_addon(
                        repo.addon_id, monitor, REPO_INSTALL_TIMEOUT
                    )
                    if outcome == "present":
                        log("Repository {} enabled".format(repo.addon_id))
                        _update_progress(
                            progress,
                            percent_complete(index + 1, total),
                            "{} enabled".format(repo.addon_id),
                        )
                        continue
                    if outcome == "aborted":
                        log("Abort requested while enabling {}".format(repo.addon_id))
                        return {"failed_repos": failed_repos, "proxy": "aborted"}
                    outcome = "not present within {} seconds after enabling".format(
                        int(REPO_INSTALL_TIMEOUT)
                    )

            log(
                "Repository {} failed: {}".format(repo.addon_id, outcome),
                xbmc.LOGERROR,
            )
            failed_repos.append(repo.addon_id)
            _update_progress(
                progress,
                percent_complete(index + 1, total),
                "{} setup failed".format(repo.addon_id),
            )
            continue
        item_progress = _ProgressView(
            progress,
            index * 100.0 / total if total else 100.0,
            100.0 / total if total else 0.0,
            repo.addon_id,
        )
        outcome = _install_repository(repo, monitor, item_progress)
        if outcome == "aborted":
            log("Abort requested; stopping repository installation")
            return {"failed_repos": failed_repos, "proxy": "aborted"}
        if outcome != "installed":
            log(
                "Repository {} failed: {}".format(repo.addon_id, outcome),
                xbmc.LOGERROR,
            )
            failed_repos.append(repo.addon_id)
            _update_progress(
                progress,
                percent_complete(index + 1, total),
                "{} setup failed".format(repo.addon_id),
            )

    if monitor.abortRequested():
        log("Abort requested; stopping repository installation")
        return {"failed_repos": failed_repos, "proxy": "aborted"}

    if monitor.abortRequested():
        log("Abort requested; stopping repository installation")
        return {"failed_repos": failed_repos, "proxy": "aborted"}

    _update_progress(progress, 100, "Refreshing addon repositories")
    if not _update_addon_repos():
        for repo in REPOSITORIES:
            if repo.addon_id not in failed_repos:
                failed_repos.append(repo.addon_id)
    proxy_status = wait_for_elementum_proxy(monitor, progress)
    return {"failed_repos": failed_repos, "proxy": proxy_status}
