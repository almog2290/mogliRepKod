import time

import xbmc
import xbmcaddon
import xbmcgui

import repositories

ADDON_ID = repositories.ADDON_ID

def _error_text(exc):
    return repositories._error_text(exc)

def _has_addon(addon_id):
    return repositories._has_addon(addon_id)

def _wait_for_addon(addon_id, monitor, timeout):
    return repositories._wait_for_addon(addon_id, monitor, timeout)

ADDON = xbmcaddon.Addon()
# (addon_id, display_name) -- mirrors addon-catalog.md for summary labels only.
ADDON_DISPLAY_NAMES = {
    "plugin.video.elementum": "Elementum",
    "script.elementum.burst": "Elementum Burst",
    "context.elementum": "Elementum Context Menu",
    "plugin.video.jellycon": "JellyCon",
    "plugin.video.jellyfin": "Jellyfin for Kodi (classic)",
    "context.subtitlesdialog.contextmenu": "Subtitles Dialog - Contextmenu",
    "service.subtitles.all_subs_plus": "All Subs Plus",
    "service.subtitles.ktuvit_plus": "Ktuvit Plus",
    "service.subtitles.opensubtitles_plus": "OpenSubtitles Plus",
    "service.subtitles.wizdom_plus": "Wizdom Plus",
}

ADDON_INSTALL_TIMEOUT = 60.0


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


class _NullMonitor(object):
    def abortRequested(self):
        return False

    def waitForAbort(self, timeout):
        return False


def _resolve_monitor_and_selected(*args, **kwargs):
    monitor = None
    selected = None

    for arg in args:
        if hasattr(arg, "abortRequested") or hasattr(arg, "waitForAbort"):
            monitor = arg
        elif isinstance(arg, (list, tuple, set)):
            selected = list(arg)

    if monitor is None:
        monitor = kwargs.get("monitor") or kwargs.get("xbmc_monitor")
    if selected is None:
        for key in ("selected", "selected_ids", "addons", "addon_ids", "ids"):
            if key in kwargs and kwargs.get(key) is not None:
                value = kwargs.get(key)
                if isinstance(value, (list, tuple, set)):
                    selected = list(value)
                else:
                    selected = [value]
                break

    if monitor is None:
        monitor = _NullMonitor()
    if selected is None:
        selected = []

    # De-duplicate while preserving order.
    seen = set()
    deduped = []
    for addon_id in selected:
        if addon_id in seen:
            continue
        seen.add(addon_id)
        deduped.append(addon_id)
    return monitor, deduped


def _is_valid_addon_id(addon_id):
    if not isinstance(addon_id, str) or not addon_id:
        return False
    for char in addon_id:
        if not (char.isalnum() or char in "._-"):
            return False
    return True


def _install_one(addon_id, monitor):
    if not _is_valid_addon_id(addon_id):
        reason = "invalid addon id"
        log("Addon {} failed: {}".format(addon_id, reason), xbmc.LOGERROR)
        return reason

    log("Installing addon {}".format(addon_id))
    try:
        xbmc.executebuiltin("InstallAddon({})".format(addon_id), True)
    except Exception as exc:
        reason = "install command failed ({})".format(_error_text(exc))
        log("Addon {} failed: {}".format(addon_id, reason), xbmc.LOGERROR)
        return reason

    outcome = _wait_for_addon(addon_id, monitor, ADDON_INSTALL_TIMEOUT)
    if outcome == "present":
        log("Addon {} installed".format(addon_id))
        return "installed"
    if outcome == "aborted":
        log("Addon {} aborted".format(addon_id))
        return "aborted"
    reason = "not present within {} seconds after InstallAddon".format(int(ADDON_INSTALL_TIMEOUT))
    log("Addon {} failed: {}".format(addon_id, reason), xbmc.LOGERROR)
    return reason


def _enable_addon(addon_id):
    if not _is_valid_addon_id(addon_id):
        return
    try:
        xbmc.executebuiltin("EnableAddon({})".format(addon_id), True)
        log("Enabled addon {}".format(addon_id))
    except Exception as exc:
        log(
            "Could not enable addon {} ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGWARNING,
        )


def _show_summary(results):
    installed = results.get("installed", [])
    skipped = results.get("skipped", [])
    failed = results.get("failed", [])

    lines = [
        "Installed: {}".format(len(installed)),
        "Skipped (already installed): {}".format(len(skipped)),
        "Failed: {}".format(len(failed)),
    ]
    if failed:
        lines.append("")
        for entry in failed:
            if isinstance(entry, (tuple, list)):
                addon_id, reason = (list(entry) + [""])[:2]
            else:
                addon_id, reason = entry, ""
            name = ADDON_DISPLAY_NAMES.get(str(addon_id), addon_id)
            lines.append("- {}: {}".format(name, reason))

    message = "\n".join(lines)
    log("Addon installation summary:\n{}".format(message))

    try:
        dialog = xbmcgui.Dialog()
        dialog.ok("Mogli Addon Setup - Install Summary", message)
    except Exception as exc:
        log(
            "Could not show addon installation summary dialog ({})".format(_error_text(exc)),
            xbmc.LOGWARNING,
        )
        try:
            xbmcgui.Dialog().notification(
                "Mogli Addon Setup",
                "Installed {} / Skipped {} / Failed {}".format(
                    len(installed), len(skipped), len(failed)
                ),
                xbmcgui.NOTIFICATION_INFO,
                5000,
            )
        except Exception:
            pass


def install_addons(*args, **kwargs):
    """Install and enable the selected addons.

    Returns a dict with keys ``installed``, ``skipped``, ``failed``.
    ``failed`` entries are ``(addon_id, reason)`` tuples.
    """
    monitor, selected_ids = _resolve_monitor_and_selected(*args, **kwargs)

    results = {"installed": [], "skipped": [], "failed": []}

    for addon_id in selected_ids:
        if monitor is not None and getattr(monitor, "abortRequested", lambda: False)():
            log("Abort requested; stopping addon installation")
            break

        try:
            if _has_addon(addon_id):
                log("Addon {} already installed, skipping".format(addon_id))
                results["skipped"].append(addon_id)
                continue

            outcome = _install_one(addon_id, monitor)
            if outcome == "installed":
                results["installed"].append(addon_id)
                _enable_addon(addon_id)
            elif outcome == "aborted":
                log("Abort requested; stopping addon installation")
                results["failed"].append((addon_id, "aborted"))
                break
            else:
                results["failed"].append((addon_id, outcome))
        except Exception as exc:
            reason = "unexpected error ({})".format(_error_text(exc))
            log("Addon {} failed: {}".format(addon_id, reason), xbmc.LOGERROR)
            results["failed"].append((addon_id, reason))

    _show_summary(results)
    return results


# Common aliases for callers/tests that use different naming.
install_selected_addons = install_addons
install_selected = install_addons
install_addon_list = install_addons
run_addon_install = install_addons
