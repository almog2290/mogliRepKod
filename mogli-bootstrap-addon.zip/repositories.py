import os
import re
import socket
import time
import urllib.parse
import urllib.request
from collections import namedtuple

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

Repository = namedtuple("Repository", "addon_id zip_url patch_jellyfin")

ELEMENTUM_PROXY_HOST = "127.0.0.1"
ELEMENTUM_PROXY_PORT = 65223
JELLYFIN_SOURCE_ROOT = "https://repo.jellyfin.org/releases/client/kodi"
JELLYFIN_PY3_SOURCE = JELLYFIN_SOURCE_ROOT + "/py3"

REPOSITORIES = (
    Repository(
        "repository.elementumorg",
        "https://raw.githubusercontent.com/almog2290/mogliRepKod/main/repository.elementumorg-0.0.2.zip",
        False,
    ),
    Repository(
        "repository.jellyfin.kodi",
        "https://kodi.jellyfin.org/repository.jellyfin.kodi.zip",
        True,
    ),
    Repository(
        "repository.burekasKodi",
        "https://raw.githubusercontent.com/almog2290/mogliRepKod/main/repository.burekasKodi-1.0.2.zip",
        False,
    ),
)

REPO_INSTALL_TIMEOUT = 60.0
PROXY_TIMEOUT = 60.0
POLL_INTERVAL = 1.0
DOWNLOAD_TIMEOUT = 60.0

_JELLYFIN_SOURCE_PATTERN = re.compile(
    re.escape(JELLYFIN_SOURCE_ROOT) + r"(?![/]?py3)(?P<suffix>/[^\s\"'<>]*)?"
)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def _error_text(exc):
    text = str(exc)
    if text:
        return "{}: {}".format(type(exc).__name__, text)
    return type(exc).__name__


def _has_addon(addon_id):
    return xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))


def _remove_file(path):
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception:
        pass


def _download_file(url, destination):
    request = urllib.request.Request(url, headers={"User-Agent": "MogliBootstrap/1.0"})
    response = urllib.request.urlopen(request, timeout=DOWNLOAD_TIMEOUT)
    try:
        target = xbmcvfs.File(destination, "wb")
        try:
            while True:
                chunk = response.read(65536)
                if not chunk:
                    break
                target.write(chunk)
        finally:
            target.close()
    finally:
        response.close()


def _repository_zip_path(repo):
    temp_dir = xbmcvfs.translatePath("special://temp/")
    xbmcvfs.mkdirs(temp_dir)
    filename = os.path.basename(urllib.parse.urlparse(repo.zip_url).path)
    if not filename:
        filename = repo.addon_id + ".zip"
    return os.path.join(temp_dir, filename)


def _wait_for_addon(addon_id, monitor, timeout):
    deadline = time.monotonic() + timeout
    while True:
        if _has_addon(addon_id):
            return "present"
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return "timeout"
        if monitor.waitForAbort(min(POLL_INTERVAL, remaining)):
            return "aborted"


def _install_repository(repo, monitor):
    try:
        destination = _repository_zip_path(repo)
    except Exception as exc:
        return "could not prepare temp path ({})".format(_error_text(exc))

    log("Downloading {} from {}".format(repo.addon_id, repo.zip_url))
    try:
        _download_file(repo.zip_url, destination)
    except Exception as exc:
        _remove_file(destination)
        return "download failed ({})".format(_error_text(exc))

    if monitor.abortRequested():
        return "aborted"

    log("Installing {} from {}".format(repo.addon_id, destination))
    try:
        xbmc.executebuiltin('InstallFromZip("{}")'.format(destination.replace('"', '\\"')), True)
    except Exception as exc:
        return "install command failed ({})".format(_error_text(exc))

    outcome = _wait_for_addon(repo.addon_id, monitor, REPO_INSTALL_TIMEOUT)
    if outcome == "present":
        log("Repository {} installed".format(repo.addon_id))
        return "installed"
    if outcome == "aborted":
        return "aborted"
    return "not present within {} seconds after InstallFromZip".format(int(REPO_INSTALL_TIMEOUT))


def _read_addon_xml(addon_xml):
    source = xbmcvfs.File(addon_xml)
    try:
        content = source.read()
    finally:
        source.close()
    if isinstance(content, bytes):
        content = content.decode("utf-8")
    return content


def _write_addon_xml(addon_xml, content):
    target = xbmcvfs.File(addon_xml, "w")
    try:
        target.write(content)
    finally:
        target.close()


def _patch_jellyfin_repository(addon_id):
    try:
        addon_path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
    except Exception as exc:
        log(
            "Could not patch {}: addon path unavailable ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return

    addon_xml = os.path.join(addon_path, "addon.xml")
    if not addon_path or not xbmcvfs.exists(addon_xml):
        log(
            "Could not patch {}: addon.xml missing at {}".format(addon_id, addon_xml),
            xbmc.LOGERROR,
        )
        return

    try:
        content = _read_addon_xml(addon_xml)
    except Exception as exc:
        log(
            "Could not read {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return

    patched, count = _JELLYFIN_SOURCE_PATTERN.subn(
        lambda match: JELLYFIN_PY3_SOURCE + (match.group("suffix") or ""),
        content,
    )
    if count == 0:
        log("Repository {} already points at {}".format(addon_id, JELLYFIN_PY3_SOURCE))
        return

    try:
        _write_addon_xml(addon_xml, patched)
    except Exception as exc:
        log(
            "Could not write {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return

    log(
        "Patched {} source URLs to {} ({} replacement{})".format(
            addon_id,
            JELLYFIN_PY3_SOURCE,
            count,
            "" if count == 1 else "s",
        )
    )


def _update_addon_repos():
    log("Updating addon repositories")
    try:
        xbmc.executebuiltin("UpdateAddonRepos")
    except Exception as exc:
        log(
            "Could not update addon repositories ({})".format(_error_text(exc)),
            xbmc.LOGERROR,
        )


def _proxy_responds():
    try:
        connection = socket.create_connection(
            (ELEMENTUM_PROXY_HOST, ELEMENTUM_PROXY_PORT),
            timeout=1.0,
        )
    except OSError:
        return False
    connection.close()
    return True


def wait_for_elementum_proxy(monitor):
    deadline = time.monotonic() + PROXY_TIMEOUT
    while True:
        if _proxy_responds():
            log(
                "Elementum proxy is responding at {}:{}".format(
                    ELEMENTUM_PROXY_HOST,
                    ELEMENTUM_PROXY_PORT,
                )
            )
            return "ready"
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            log(
                "Elementum proxy did not respond at {}:{} within {} seconds".format(
                    ELEMENTUM_PROXY_HOST,
                    ELEMENTUM_PROXY_PORT,
                    int(PROXY_TIMEOUT),
                ),
                xbmc.LOGERROR,
            )
            return "timeout"
        if monitor.waitForAbort(min(POLL_INTERVAL, remaining)):
            log("Abort requested while waiting for the Elementum proxy")
            return "aborted"


def install_repositories(monitor):
    failed_repos = []
    for repo in REPOSITORIES:
        if monitor.abortRequested():
            log("Abort requested; stopping repository installation")
            return {"failed_repos": failed_repos, "proxy": "aborted"}
        if _has_addon(repo.addon_id):
            log("Repository {} already installed, skipping".format(repo.addon_id))
            continue
        outcome = _install_repository(repo, monitor)
        if outcome == "aborted":
            log("Abort requested; stopping repository installation")
            return {"failed_repos": failed_repos, "proxy": "aborted"}
        if outcome != "installed":
            log(
                "Repository {} failed: {}".format(repo.addon_id, outcome),
                xbmc.LOGERROR,
            )
            failed_repos.append(repo.addon_id)

    if monitor.abortRequested():
        log("Abort requested; stopping repository installation")
        return {"failed_repos": failed_repos, "proxy": "aborted"}

    for repo in REPOSITORIES:
        if repo.patch_jellyfin:
            _patch_jellyfin_repository(repo.addon_id)

    if monitor.abortRequested():
        log("Abort requested; stopping repository installation")
        return {"failed_repos": failed_repos, "proxy": "aborted"}

    _update_addon_repos()
    proxy_status = wait_for_elementum_proxy(monitor)
    return {"failed_repos": failed_repos, "proxy": proxy_status}
