import os
import re
import socket
import time
import urllib.parse
import urllib.request
from collections import namedtuple

import xbmc
import xbmcaddon
import xbmcvfs

from progress import percent_complete

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

Repository = namedtuple("Repository", "addon_id zip_url patch_jellyfin")

ELEMENTUM_PROXY_HOST = "127.0.0.1"
ELEMENTUM_PROXY_PORT = 65223
JELLYFIN_SOURCE_ROOT = "https://repo.jellyfin.org/releases/client/kodi"
JELLYFIN_PY3_SOURCE = JELLYFIN_SOURCE_ROOT + "/py3"

REPOSITORIES = (
    Repository(
        "repository.elementumorg",
        "https://raw.githubusercontent.com/almog2290/mogliRepKod/main/repository.elementumorg-0.0.2.zip",
        False,
    ),
    Repository(
        "repository.jellyfin.kodi",
        "https://kodi.jellyfin.org/repository.jellyfin.kodi.zip",
        True,
    ),
    Repository(
        "repository.burekasKodi",
        "https://raw.githubusercontent.com/almog2290/mogliRepKod/main/repository.burekasKodi-1.0.2.zip",
        False,
    ),
)

REPO_INSTALL_TIMEOUT = 60.0
PROXY_TIMEOUT = 60.0
POLL_INTERVAL = 1.0
DOWNLOAD_TIMEOUT = 60.0

_JELLYFIN_SOURCE_PATTERN = re.compile(
    re.escape(JELLYFIN_SOURCE_ROOT) + r"(?![/]?py3)(?P<suffix>/[^\s\"'<>]*)?"
)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def _error_text(exc):
    text = str(exc)
    if text:
        return "{}: {}".format(type(exc).__name__, text)
    return type(exc).__name__


def _update_progress(progress, percent, message):
    if progress is None:
        return
    try:
        progress.update(percent, message)
    except Exception as exc:
        log("Progress update failed ({})".format(_error_text(exc)), xbmc.LOGWARNING)


class _ProgressView(object):
    """Map a subtask's percentage into a range of its parent progress."""

    def __init__(self, parent, start, span, prefix=""):
        self.parent = parent
        self.start = start
        self.span = span
        self.prefix = prefix

    def update(self, percent, message=""):
        if self.parent is None:
            return
        try:
            fraction = max(0.0, min(100.0, float(percent))) / 100.0
        except Exception:
            fraction = 0.0
        if self.prefix and message:
            message = "{}: {}".format(self.prefix, message)
        elif self.prefix:
            message = self.prefix
        _update_progress(self.parent, self.start + self.span * fraction, message)


class _DownloadAborted(Exception):
    pass


def _has_addon(addon_id):
    if not xbmc.getCondVisibility("System.HasAddon({})".format(addon_id)):
        return False
    try:
        addon_path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
    except Exception:
        return False
    return bool(addon_path and xbmcvfs.exists(os.path.join(addon_path, "addon.xml")))


def _remove_file(path):
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception:
        pass


def _download_file(url, destination, progress=None, monitor=None):
    request = urllib.request.Request(url, headers={"User-Agent": "MogliBootstrap/1.0"})
    response = urllib.request.urlopen(request, timeout=DOWNLOAD_TIMEOUT)
    try:
        try:
            total = int(response.headers.get("Content-Length", 0))
        except Exception:
            total = 0
        downloaded = 0
        target = xbmcvfs.File(destination, "wb")
        try:
            while True:
                if monitor is not None and monitor.abortRequested():
                    raise _DownloadAborted()
                chunk = response.read(65536)
                if not chunk:
                    break
                target.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    _update_progress(
                        progress,
                        downloaded * 100.0 / total,
                        "Downloading archive",
                    )
        finally:
            target.close()
    finally:
        response.close()


def _repository_zip_path(repo):
    temp_dir = xbmcvfs.translatePath("special://temp/")
    xbmcvfs.mkdirs(temp_dir)
    filename = os.path.basename(urllib.parse.urlparse(repo.zip_url).path)
    if not filename:
        filename = repo.addon_id + ".zip"
    return os.path.join(temp_dir, filename)


def _wait_for_addon(addon_id, monitor, timeout):
    deadline = time.monotonic() + timeout
    while True:
        if _has_addon(addon_id):
            return "present"
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return "timeout"
        if monitor.waitForAbort(min(POLL_INTERVAL, remaining)):
            return "aborted"


def _install_repository(repo, monitor, progress=None):
    try:
        destination = _repository_zip_path(repo)
    except Exception as exc:
        return "could not prepare temp path ({})".format(_error_text(exc))

    log("Downloading {} from {}".format(repo.addon_id, repo.zip_url))
    _update_progress(progress, 0, "Downloading archive")
    download_progress = _ProgressView(progress, 0, 75)
    try:
        _download_file(repo.zip_url, destination, download_progress, monitor)
    except _DownloadAborted:
        _remove_file(destination)
        return "aborted"
    except Exception as exc:
        _remove_file(destination)
        return "download failed ({})".format(_error_text(exc))

    if monitor.abortRequested():
        return "aborted"

    try:
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
    except Exception as exc:
        return "could not prepare addons path ({})".format(_error_text(exc))
    if not addons_dir:
        return "could not prepare addons path (translated path is empty)"

    log("Extracting {} to {}".format(destination, addons_dir))
    _update_progress(progress, 80, "Extracting archive")
    try:
        xbmc.executebuiltin(
            'Extract("{}", "{}")'.format(
                destination.replace('"', '\\"'), addons_dir.replace('"', '\\"')
            ),
            True,
        )
    except Exception as exc:
        return "extraction failed ({})".format(_error_text(exc))

    _update_progress(progress, 90, "Refreshing local addons")
    try:
        xbmc.executebuiltin("UpdateLocalAddons", True)
    except Exception as exc:
        return "local addon refresh failed ({})".format(_error_text(exc))

    _update_progress(progress, 95, "Confirming repository installation")
    outcome = _wait_for_addon(repo.addon_id, monitor, REPO_INSTALL_TIMEOUT)
    if outcome == "present":
        log("Repository {} installed".format(repo.addon_id))
        _update_progress(progress, 100, "Repository installed")
        return "installed"
    if outcome == "aborted":
        return "aborted"
    return "not present within {} seconds after extraction".format(int(REPO_INSTALL_TIMEOUT))


def _read_addon_xml(addon_xml):
    source = xbmcvfs.File(addon_xml)
    try:
        content = source.read()
    finally:
        source.close()
    if isinstance(content, bytes):
        content = content.decode("utf-8")
    return content


def _write_addon_xml(addon_xml, content):
    target = xbmcvfs.File(addon_xml, "w")
    try:
        target.write(content)
    finally:
        target.close()


def _patch_jellyfin_repository(addon_id):
    try:
        addon_path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
    except Exception as exc:
        log(
            "Could not patch {}: addon path unavailable ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return

    addon_xml = os.path.join(addon_path, "addon.xml")
    if not addon_path or not xbmcvfs.exists(addon_xml):
        log(
            "Could not patch {}: addon.xml missing at {}".format(addon_id, addon_xml),
            xbmc.LOGERROR,
        )
        return

    try:
        content = _read_addon_xml(addon_xml)
    except Exception as exc:
        log(
            "Could not read {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return

    patched, count = _JELLYFIN_SOURCE_PATTERN.subn(
        lambda match: JELLYFIN_PY3_SOURCE + (match.group("suffix") or ""),
        content,
    )
    if count == 0:
        log("Repository {} already points at {}".format(addon_id, JELLYFIN_PY3_SOURCE))
        return

    try:
        _write_addon_xml(addon_xml, patched)
    except Exception as exc:
        log(
            "Could not write {} addon.xml ({})".format(addon_id, _error_text(exc)),
            xbmc.LOGERROR,
        )
        return

    log(
        "Patched {} source URLs to {} ({} replacement{})".format(
            addon_id,
            JELLYFIN_PY3_SOURCE,
            count,
            "" if count == 1 else "s",
        )
    )


def _update_addon_repos():
    log("Updating addon repositories")
    try:
        xbmc.executebuiltin("UpdateAddonRepos")
    except Exception as exc:
        log(
            "Could not update addon repositories ({})".format(_error_text(exc)),
            xbmc.LOGERROR,
        )


def _proxy_responds():
    try:
        connection = socket.create_connection(
            (ELEMENTUM_PROXY_HOST, ELEMENTUM_PROXY_PORT),
            timeout=1.0,
        )
    except OSError:
        return False
    connection.close()
    return True


def wait_for_elementum_proxy(monitor, progress=None):
    deadline = time.monotonic() + PROXY_TIMEOUT
    while True:
        if monitor.abortRequested():
            log("Abort requested while waiting for the Elementum proxy")
            return "aborted"
        _update_progress(progress, 100, "Waiting for the Elementum proxy")
        if _proxy_responds():
            log(
                "Elementum proxy is responding at {}:{}".format(
                    ELEMENTUM_PROXY_HOST,
                    ELEMENTUM_PROXY_PORT,
                )
            )
            _update_progress(progress, 100, "Elementum proxy is ready")
            return "ready"
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            log(
                "Elementum proxy did not respond at {}:{} within {} seconds".format(
                    ELEMENTUM_PROXY_HOST,
                    ELEMENTUM_PROXY_PORT,
                    int(PROXY_TIMEOUT),
                ),
                xbmc.LOGERROR,
            )
            _update_progress(progress, 100, "Elementum proxy is not responding")
            return "timeout"
        if monitor.waitForAbort(min(POLL_INTERVAL, remaining)):
            log("Abort requested while waiting for the Elementum proxy")
            return "aborted"


def install_repositories(monitor, progress=None):
    failed_repos = []
    total = len(REPOSITORIES)
    for index, repo in enumerate(REPOSITORIES):
        if monitor.abortRequested():
            log("Abort requested; stopping repository installation")
            return {"failed_repos": failed_repos, "proxy": "aborted"}
        _update_progress(
            progress,
            percent_complete(index, total),
            "Checking {}".format(repo.addon_id),
        )
        if _has_addon(repo.addon_id):
            log("Repository {} already installed, skipping".format(repo.addon_id))
            _update_progress(
                progress,
                percent_complete(index + 1, total),
                "{} already installed; skipping".format(repo.addon_id),
            )
            continue
        item_progress = _ProgressView(
            progress,
            index * 100.0 / total if total else 100.0,
            100.0 / total if total else 0.0,
            repo.addon_id,
        )
        outcome = _install_repository(repo, monitor, item_progress)
        if outcome == "aborted":
            log("Abort requested; stopping repository installation")
            return {"failed_repos": failed_repos, "proxy": "aborted"}
        if outcome != "installed":
            log(
                "Repository {} failed: {}".format(repo.addon_id, outcome),
                xbmc.LOGERROR,
            )
            failed_repos.append(repo.addon_id)
            _update_progress(
                progress,
                percent_complete(index + 1, total),
                "{} setup failed".format(repo.addon_id),
            )

    if monitor.abortRequested():
        log("Abort requested; stopping repository installation")
        return {"failed_repos": failed_repos, "proxy": "aborted"}

    for repo in REPOSITORIES:
        if repo.patch_jellyfin:
            _update_progress(progress, 100, "Checking Jellyfin repository source")
            _patch_jellyfin_repository(repo.addon_id)

    if monitor.abortRequested():
        log("Abort requested; stopping repository installation")
        return {"failed_repos": failed_repos, "proxy": "aborted"}

    _update_progress(progress, 100, "Refreshing addon repositories")
    _update_addon_repos()
    proxy_status = wait_for_elementum_proxy(monitor, progress)
    return {"failed_repos": failed_repos, "proxy": proxy_status}
